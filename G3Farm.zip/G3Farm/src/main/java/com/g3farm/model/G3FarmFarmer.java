package com.g3farm.model;
import javax.persistence.*;
@Entity
@Table(name = "Farm_Farmers")
public class G3FarmFarmer {
	@Id 
	@Column(name = "FId")
	private int FId;
	@Column(name = "FName")
	private String  FName;
	@Column(name = "FContact", length = 10)
	private int FContact;
	public int getFId() {
		return FId;
	}
	public void setFId(int fId) {
		FId = fId;
	}
	public String getFName() {
		return FName;
	}
	public void setFName(String fName) {
		FName = fName;
	}
	public int getFContact() {
		return FContact;
	}
	public void setFContact(int fContact) {
		FContact = fContact;
	}
	

}












