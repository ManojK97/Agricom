package com.g3farm.model;
@Entity
@Table(name = "Farm_Land")
public class G3FarmLand 
{
	//Column Attributes
	@Id 
	@Column(name = "LId")
	@Column(name = "LArea")
	private int  LArea;
	private int LId;
	//getter and setters
	public int getLId()
	{
		return LId;
	}
	public void setLId(int lId) 
	{
		LId = lId;
	}
	public int getLArea()
	{
		return LArea;
	}
	public void setLArea(int lArea)
	{
		LArea = lArea;
	}

	

}
